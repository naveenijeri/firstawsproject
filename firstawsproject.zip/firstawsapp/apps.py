from django.apps import AppConfig


class FirstawsappConfig(AppConfig):
    name = 'firstawsapp'
